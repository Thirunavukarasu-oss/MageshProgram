﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class student
    {
        public student(string fatherName, string motherName, string brotherName, string myName, string loversName)
        {
           this. FatherName = fatherName;
            this.MotherName = motherName;
            this.BrotherName = brotherName;
            this.MyName = myName;
            this.LoversName = loversName;
        }

        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string BrotherName { get; set; }
        public string MyName { get; set; }
        public string LoversName { get; set; }

        public override string ToString()
        {
            return " FatherName: " + FatherName + " " +
                    "MotherName:" + MotherName + " " +
                    "BrotherName:" + BrotherName + " " +
                    "MyName:" + MyName + " " +
                    "LoversName:" + LoversName;


        }

    }
}
