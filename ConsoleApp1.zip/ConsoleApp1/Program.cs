﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        List<string> skillNames = new List<string>();
        static int fileNumber = 0;
        static void Main(string[] args)
        {

            Program program = new Program();
            program.addSkils();
            string[] filePaths = Directory.GetFiles(@"C:\Users\mageshr\Downloads\resumes");
            Console.WriteLine("Started the finding");
            foreach (String filePath in filePaths)
            {
                program.readFile(filePath);    
            }
            Console.WriteLine("Ended the finding");
            Console.ReadKey();
        }
            public void addSkils()
            {
                skillNames.Add("C");
                skillNames.Add("C++");
                skillNames.Add("MYSQL");
            }

            public void readFile(String filePath)
            {
                List<string> lines = new List<string>();
                lines = File.ReadAllLines(filePath).ToList();
                foreach (String line in lines)
                {
                    if (line.ToUpper().Contains("SKILLS"))
                    {
                    //line = Skills:c++,mobile application development,Data Science
                    string[] index = line.Split(':');
                       /* index[0] = Skills
                        index[1] = c++,mobile application development,Data Science*/
                        string[] indexx = index[1].Split(',');
                        foreach (string skillName in indexx)
                        {
                            if (skillNames.Contains(skillName.Trim().ToUpper()))
                            {
                                writeFile(filePath);
                                break;
                            }
                        }
                    }
                   
                }
            }

            public void writeFile(String filePath)
            {
               
                List<string> lines = new List<string>();
                string fileName = getFileName(filePath);
                string path = @"C:\Users\mageshr\Downloads\selectedResumes\"+ fileName+".txt";
                if (File.Exists(path))
                {
                    fileNumber++;
                    path = @"C:\Users\mageshr\Downloads\selectedResumes\" + fileName + "-" + fileNumber + ".txt";
                }
            using (StreamWriter sw = File.CreateText(path))
                    {
                        lines = File.ReadAllLines(filePath).ToList();
                        foreach (String line in lines)
                        {
                            sw.WriteLine(line);
                        }
                    }

             }

            public String getFileName(String filePath)
            {
                List<string> lines = new List<string>();
                lines = File.ReadAllLines(filePath).ToList();
                string nameOfCandidate = null;
                foreach (String line in lines)
                {
                    if (line.ToUpper().Contains("NAME"))
                    {
                        nameOfCandidate = line.Substring(5);
                        break;
                    }
                }
                 return nameOfCandidate;
            }

        }
    }
